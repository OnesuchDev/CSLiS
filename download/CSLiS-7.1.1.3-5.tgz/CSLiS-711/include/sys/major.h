must add str devs
